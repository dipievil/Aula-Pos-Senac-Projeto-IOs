//
//  ContainerUsuarios.swift
//  senac-3-projeto
//
//  Created by Nicolas Nascimento on 30/10/21.
//

import Foundation

struct ContainerUsuarios {
    
    static let usuarios = [
        Usuario(nome: "Nicolas Nascimento", numero: "+5551999999999"),
        Usuario(nome: "Matheus Souza", numero: "+5551888888888"),
    ]
    
}
