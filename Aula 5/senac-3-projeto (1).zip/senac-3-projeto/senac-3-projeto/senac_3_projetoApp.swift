//
//  senac_3_projetoApp.swift
//  senac-3-projeto
//
//  Created by Nicolas Nascimento on 30/10/21.
//

import SwiftUI

@main
struct senac_3_projetoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
