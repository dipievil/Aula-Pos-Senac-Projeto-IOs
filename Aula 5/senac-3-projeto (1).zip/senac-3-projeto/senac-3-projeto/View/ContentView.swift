//
//  ContentView.swift
//  senac-3-projeto
//
//  Created by Nicolas Nascimento on 30/10/21.
//

import SwiftUI

struct ContentView: View {
    
    @State var mensagens = ContainerMensagens().mensagens
    
    var body: some View {
        
        VStack {
            Spacer()
            
            ForEach(mensagens) { mensagem in
                
                MensagemView(
                    usuario: mensagem.remetente.nome.contains("Nicolas") ? nil : mensagem.remetente,
                    conteudo: mensagem.conteudo,
                    hora: dateToString(date: mensagem.hora),
                    status: mensagem.status.rawValue
                )
                
            }
        }.padding()
    }
    
    func dateToString(date: Date) -> String {
        
        let formatter = DateFormatter()
        formatter.dateFormat = "hh mm a"
        return formatter.string(from: date)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
