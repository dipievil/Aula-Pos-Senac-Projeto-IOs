//
//  ContentView.swift
//  senac-4-projeto
//
//  Created by Nicolas Nascimento on 30/10/21.
//

import SwiftUI

struct ContentView: View {
    
    @State var appState: AppState = AppState()
    
    var body: some View {
        
        ZStack {
            if appState.background == .black {
                Color.black
            } else {
                Color.white
            }
            
            Text(appState.label)
                .foregroundColor(appState.background == .white ? .black : .white)
                .padding()
                .onTapGesture {
                    appState.switchState()
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
