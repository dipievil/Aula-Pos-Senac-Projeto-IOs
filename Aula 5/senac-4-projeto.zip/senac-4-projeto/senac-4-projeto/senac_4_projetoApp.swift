//
//  senac_4_projetoApp.swift
//  senac-4-projeto
//
//  Created by Nicolas Nascimento on 30/10/21.
//

import SwiftUI

@main
struct senac_4_projetoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
