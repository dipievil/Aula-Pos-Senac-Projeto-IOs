//
//  senac_4_projetoUITests.swift
//  senac-4-projetoUITests
//
//  Created by Nicolas Nascimento on 30/10/21.
//

import XCTest

class senac_4_projetoUITests: XCTestCase {

    
}
